#ifndef Py_INTERNAL_HASH_H
#define Py_INTERNAL_HASH_H

uint64_t _Py_KeyedHash(uint64_t, const char *, Py_ssize_t);

#endif
